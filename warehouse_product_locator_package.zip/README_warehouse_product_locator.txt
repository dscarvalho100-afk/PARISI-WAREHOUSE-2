Warehouse Product Locator

Files included:
- warehouse_product_locator.html

How to use:
1. Open the HTML file in any browser.
2. Type a product code.
3. Click Search.
4. The page will show all locations found for that code from the Excel file.

Notes:
- Interface is in English.
- Search works with exact code and partial code.
- Data source used:
  - Sheet: Planilha1
  - Column A: locations
  - Column F: product codes
