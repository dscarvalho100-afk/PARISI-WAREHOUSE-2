# Warehouse Product Locator

This package is ready for **GitHub Pages**.

## Files
- `index.html` → main website
- `.nojekyll` → helps GitHub Pages serve the site as a static page

## How to publish on GitHub Pages
1. Create a new repository on GitHub.
2. Upload `index.html` and `.nojekyll` to the repository root.
3. Go to **Settings** → **Pages**.
4. In **Build and deployment**, choose:
   - **Source:** Deploy from a branch
   - **Branch:** `main`
   - **Folder:** `/ (root)`
5. Save.
6. Wait a minute and GitHub will generate your public link.

Your site URL will usually look like:
`https://YOUR-USERNAME.github.io/YOUR-REPOSITORY-NAME/`

## Search behavior
- Exact code matches are prioritized.
- Partial matches are also supported.
- All locations found for the same code are displayed.
